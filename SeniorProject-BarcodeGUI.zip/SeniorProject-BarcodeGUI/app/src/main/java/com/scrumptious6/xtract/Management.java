package com.scrumptious6.xtract;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Management extends AppCompatActivity {
    private Button dataBase;
    private Button scanlist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_management);
        dataBase = (Button) findViewById(R.id.dataBase);
        dataBase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dataActivity = new Intent( Management.this, Database.class);
                startActivity(dataActivity);
            }
        });

        scanlist = (Button) findViewById(R.id.scanlist);
        scanlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent scanActivity = new Intent( Management.this, Scanlist.class);
                startActivity(scanActivity);
            }
        });
    }

}
